package com.appointment.mgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
